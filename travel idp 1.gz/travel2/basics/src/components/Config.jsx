import React from 'react';
import './Config.css'; // Import the individual CSS file

const Config = () => {
  return (
    <div className="config-page-background"> {/* Use the class for background */}
      <h1>Configuration</h1>
      <p>Adjust your settings here!</p>
      {/* Add more content as needed */}
    </div>
  );
};

export default Config;
